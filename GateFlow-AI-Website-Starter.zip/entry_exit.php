<?php
include 'config/database.php';
$result = $conn->query("SELECT * FROM entry_exit ORDER BY record_id DESC");
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Entry Exit - GateFlow-AI</title><link rel="stylesheet" href="css/style.css"></head>
<body><?php include 'includes/sidebar.php'; ?><main class="main-content">
<div class="topbar"><div><h2>Entry / Exit Management</h2><p>Track vehicles currently inside and historical movement</p></div></div>
<div class="panel"><div class="table-wrap"><table>
<thead><tr><th>Vehicle</th><th>Entry Time</th><th>Exit Time</th><th>Access</th><th>Status</th></tr></thead>
<tbody><?php while($r=$result->fetch_assoc()): ?><tr>
<td><?= htmlspecialchars($r['vehicle_number']) ?></td><td><?= $r['entry_time'] ?></td><td><?= $r['exit_time'] ?: '-' ?></td><td><?= $r['access_type'] ?></td>
<td><span class="badge <?= $r['status']==='INSIDE'?'green':'gray' ?>"><?= $r['status'] ?></span></td>
</tr><?php endwhile; ?></tbody></table></div></div>
</main></body></html>
