<?php
include 'config/database.php';
$result = $conn->query("SELECT user_id,name,email,role,created_at FROM users ORDER BY user_id DESC");
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Users - GateFlow-AI</title><link rel="stylesheet" href="css/style.css"></head>
<body><?php include 'includes/sidebar.php'; ?><main class="main-content">
<div class="topbar"><div><h2>User Management</h2><p>Administrators and security personnel</p></div></div>
<div class="panel"><div class="table-wrap"><table><thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Created</th></tr></thead><tbody>
<?php while($r=$result->fetch_assoc()): ?><tr><td><?= $r['user_id'] ?></td><td><?= htmlspecialchars($r['name']) ?></td><td><?= htmlspecialchars($r['email']) ?></td><td><?= $r['role'] ?></td><td><?= $r['created_at'] ?></td></tr><?php endwhile; ?>
</tbody></table></div><p class="muted">Authentication can be added next.</p></div>
</main></body></html>
