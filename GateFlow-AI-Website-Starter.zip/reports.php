<?php
include 'config/database.php';
$vehicles = $conn->query("SELECT COUNT(*) total FROM vehicles")->fetch_assoc()['total'];
$records = $conn->query("SELECT COUNT(*) total FROM entry_exit")->fetch_assoc()['total'];
$alerts = $conn->query("SELECT COUNT(*) total FROM alerts")->fetch_assoc()['total'];
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Reports - GateFlow-AI</title><link rel="stylesheet" href="css/style.css"></head>
<body><?php include 'includes/sidebar.php'; ?><main class="main-content">
<div class="topbar"><div><h2>Reports</h2><p>GateFlow-AI operational summary</p></div></div>
<section class="stats-grid">
<div class="stat-card"><span>Registered Vehicles</span><strong><?= $vehicles ?></strong></div>
<div class="stat-card"><span>Entry/Exit Records</span><strong><?= $records ?></strong></div>
<div class="stat-card alert-stat"><span>Total Alerts</span><strong><?= $alerts ?></strong></div>
</section>
<div class="panel"><h3>Available Reports</h3><div class="quick-actions">
<a href="vehicles.php">Vehicle Report</a><a href="entry_exit.php">Entry / Exit Report</a><a href="alerts.php">Alert Report</a><a href="crowd_monitoring.php">Crowd Monitoring Report</a>
</div></div>
</main></body></html>
