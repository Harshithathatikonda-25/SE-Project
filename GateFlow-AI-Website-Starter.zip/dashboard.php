<?php
include 'config/database.php';

$totalVehicles = $conn->query("SELECT COUNT(*) AS total FROM vehicles")->fetch_assoc()['total'];
$insideVehicles = $conn->query("SELECT COUNT(*) AS total FROM entry_exit WHERE status='INSIDE'")->fetch_assoc()['total'];
$totalEntries = $conn->query("SELECT COUNT(*) AS total FROM entry_exit")->fetch_assoc()['total'];
$totalAlerts = $conn->query("SELECT COUNT(*) AS total FROM alerts WHERE status='New'")->fetch_assoc()['total'];

$recent = $conn->query("SELECT * FROM entry_exit ORDER BY record_id DESC LIMIT 8");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>GateFlow-AI Dashboard</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include 'includes/sidebar.php'; ?>

<main class="main-content">
    <div class="topbar">
        <div>
            <h2>GateFlow-AI Dashboard</h2>
            <p>AI-powered campus gate monitoring system</p>
        </div>
        <span class="system-online">● System Online</span>
    </div>

    <section class="stats-grid">
        <div class="stat-card"><span>Total Vehicles</span><strong><?= $totalVehicles ?></strong></div>
        <div class="stat-card"><span>Vehicles Inside</span><strong><?= $insideVehicles ?></strong></div>
        <div class="stat-card"><span>Total Entry/Exit</span><strong><?= $totalEntries ?></strong></div>
        <div class="stat-card alert-stat"><span>Active Alerts</span><strong><?= $totalAlerts ?></strong></div>
    </section>

    <section class="content-grid">
        <div class="panel">
            <div class="panel-title"><h3>Recent Vehicle Activity</h3><a href="entry_exit.php">View all</a></div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>Vehicle</th><th>Entry</th><th>Exit</th><th>Status</th></tr></thead>
                    <tbody>
                    <?php while($row = $recent->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['vehicle_number']) ?></td>
                            <td><?= htmlspecialchars($row['entry_time'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($row['exit_time'] ?? '-') ?></td>
                            <td><span class="badge <?= $row['status']==='INSIDE' ? 'green' : 'gray' ?>"><?= $row['status'] ?></span></td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="panel">
            <h3>Quick Actions</h3>
            <div class="quick-actions">
                <a href="add_vehicle.php">+ Add Vehicle</a>
                <a href="anpr.php">Open ANPR</a>
                <a href="alerts.php">View Alerts</a>
                <a href="reports.php">Generate Reports</a>
            </div>
            <div class="system-check">
                <p><span class="dot"></span> Database Connected</p>
                <p><span class="dot"></span> ANPR Module Ready</p>
                <p><span class="dot"></span> CCTV Module Ready</p>
                <p><span class="dot"></span> Gate Controller Ready</p>
            </div>
        </div>
    </section>
</main>
</body>
</html>
