<?php
include 'config/database.php';
$result = $conn->query("SELECT * FROM crowd_monitoring ORDER BY monitoring_id DESC LIMIT 20");
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Crowd Monitoring - GateFlow-AI</title><link rel="stylesheet" href="css/style.css"></head>
<body><?php include 'includes/sidebar.php'; ?><main class="main-content">
<div class="topbar"><div><h2>Crowd & Traffic Monitoring</h2><p>Monitor crowd count and density levels</p></div></div>
<div class="panel"><div class="table-wrap"><table><thead><tr><th>Location</th><th>Count</th><th>Density</th><th>Recorded At</th></tr></thead><tbody>
<?php while($r=$result->fetch_assoc()): ?><tr><td><?= htmlspecialchars($r['location']) ?></td><td><?= $r['crowd_count'] ?></td><td><?= $r['density_level'] ?></td><td><?= $r['recorded_at'] ?></td></tr><?php endwhile; ?>
</tbody></table></div><p class="muted">Add AI crowd-counting data from your Python/OpenCV module later.</p></div>
</main></body></html>
