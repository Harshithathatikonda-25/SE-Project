<aside class="sidebar">
    <div class="brand">
        <div class="brand-icon">G</div>
        <div><strong>GateFlow-AI</strong><small>Smart Campus Security</small></div>
    </div>

    <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="vehicles.php">Vehicles</a>
        <a href="entry_exit.php">Entry / Exit</a>
        <a href="anpr.php">ANPR</a>
        <a href="camera.php">CCTV Monitoring</a>
        <a href="crowd_monitoring.php">Crowd Monitoring</a>
        <a href="alerts.php">Alerts</a>
        <a href="reports.php">Reports</a>
        <a href="users.php">Users</a>
    </nav>
</aside>
