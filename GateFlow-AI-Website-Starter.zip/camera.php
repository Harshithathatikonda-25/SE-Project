<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>CCTV - GateFlow-AI</title><link rel="stylesheet" href="css/style.css"></head>
<body><?php include 'includes/sidebar.php'; ?><main class="main-content">
<div class="topbar"><div><h2>CCTV Monitoring</h2><p>Monitor connected campus cameras and events</p></div></div>
<div class="camera-grid">
<div class="panel"><h3>Gate Camera 01</h3><div class="camera-screen">LIVE CAMERA FEED</div><span class="badge green">ONLINE</span></div>
<div class="panel"><h3>Gate Camera 02</h3><div class="camera-screen">LIVE CAMERA FEED</div><span class="badge green">ONLINE</span></div>
<div class="panel"><h3>Parking Camera</h3><div class="camera-screen">LIVE CAMERA FEED</div><span class="badge yellow">STANDBY</span></div>
</div></main></body></html>
