<?php
include 'config/database.php';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $conn->prepare("INSERT INTO vehicles (vehicle_number, owner_name, vehicle_type, department, phone, status) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $_POST['vehicle_number'], $_POST['owner_name'], $_POST['vehicle_type'], $_POST['department'], $_POST['phone'], $_POST['status']);
    if ($stmt->execute()) {
        header("Location: vehicles.php");
        exit;
    }
    $message = "Could not add vehicle. Vehicle number may already exist.";
}
?>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Add Vehicle - GateFlow-AI</title><link rel="stylesheet" href="css/style.css"></head>
<body><?php include 'includes/sidebar.php'; ?><main class="main-content">
<div class="topbar"><div><h2>Add Vehicle</h2><p>Register a vehicle in the GateFlow-AI database</p></div></div>
<div class="panel form-panel">
<?php if($message): ?><div class="error"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<form method="post" class="form-grid">
<label>Vehicle Number<input name="vehicle_number" required placeholder="TS09AB1234"></label>
<label>Owner Name<input name="owner_name" required></label>
<label>Vehicle Type<select name="vehicle_type"><option>Car</option><option>Bike</option><option>Bus</option><option>Other</option></select></label>
<label>Department<input name="department"></label>
<label>Phone<input name="phone"></label>
<label>Status<select name="status"><option>Authorized</option><option>Pending</option><option>Blocked</option></select></label>
<div><button class="btn-primary" type="submit">Save Vehicle</button> <a class="btn-secondary" href="vehicles.php">Cancel</a></div>
</form></div></main></body></html>
