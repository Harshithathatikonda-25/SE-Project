<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ANPR - GateFlow-AI</title><link rel="stylesheet" href="css/style.css"></head>
<body><?php include 'includes/sidebar.php'; ?><main class="main-content">
<div class="topbar"><div><h2>ANPR Vehicle Detection</h2><p>Automatic Number Plate Recognition interface</p></div><span class="system-online">● ANPR Ready</span></div>
<div class="content-grid">
<div class="panel camera-placeholder"><div class="camera-screen"><div>CAMERA FEED</div><small>Connect Python/OpenCV ANPR stream here</small></div></div>
<div class="panel"><h3>Recognition Result</h3>
<div class="result-box"><span>Detected Plate</span><strong>TS09AB1234</strong><span>Status</span><b class="badge green">AUTHORIZED</b></div>
<div class="quick-actions"><button class="btn-primary" onclick="alert('Gate open command placeholder')">Allow Entry</button><button class="btn-secondary" onclick="alert('Gate deny command placeholder')">Deny Entry</button></div>
</div></div>
</main></body></html>
