<?php
include 'config/database.php';
$result = $conn->query("SELECT * FROM alerts ORDER BY alert_id DESC");
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Alerts - GateFlow-AI</title><link rel="stylesheet" href="css/style.css"></head>
<body><?php include 'includes/sidebar.php'; ?><main class="main-content">
<div class="topbar"><div><h2>Alerts & Incidents</h2><p>Unauthorized vehicles, risk events and security alerts</p></div></div>
<div class="panel"><div class="table-wrap"><table><thead><tr><th>Vehicle</th><th>Type</th><th>Description</th><th>Severity</th><th>Status</th><th>Time</th></tr></thead><tbody>
<?php while($r=$result->fetch_assoc()): ?><tr>
<td><?= htmlspecialchars($r['vehicle_number'] ?: '-') ?></td><td><?= htmlspecialchars($r['alert_type']) ?></td><td><?= htmlspecialchars($r['description']) ?></td>
<td><span class="badge <?= in_array($r['severity'],['High','Critical'])?'red':($r['severity']==='Medium'?'yellow':'green') ?>"><?= $r['severity'] ?></span></td>
<td><?= $r['status'] ?></td><td><?= $r['created_at'] ?></td>
</tr><?php endwhile; ?></tbody></table></div></div>
</main></body></html>
