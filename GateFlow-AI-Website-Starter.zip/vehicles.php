<?php
include 'config/database.php';
$result = $conn->query("SELECT * FROM vehicles ORDER BY vehicle_id DESC");
?>
<!DOCTYPE html>
<html><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Vehicles - GateFlow-AI</title>
<link rel="stylesheet" href="css/style.css">
</head><body>
<?php include 'includes/sidebar.php'; ?>
<main class="main-content">
<div class="topbar"><div><h2>Vehicle Management</h2><p>Registered and authorized campus vehicles</p></div><a class="btn-primary" href="add_vehicle.php">+ Add Vehicle</a></div>
<div class="panel">
<div class="table-wrap"><table>
<thead><tr><th>ID</th><th>Vehicle Number</th><th>Owner</th><th>Type</th><th>Department</th><th>Status</th></tr></thead>
<tbody>
<?php while($r=$result->fetch_assoc()): ?>
<tr>
<td><?= $r['vehicle_id'] ?></td>
<td><strong><?= htmlspecialchars($r['vehicle_number']) ?></strong></td>
<td><?= htmlspecialchars($r['owner_name']) ?></td>
<td><?= htmlspecialchars($r['vehicle_type']) ?></td>
<td><?= htmlspecialchars($r['department']) ?></td>
<td><span class="badge <?= $r['status']==='Authorized'?'green':($r['status']==='Blocked'?'red':'yellow') ?>"><?= $r['status'] ?></span></td>
</tr>
<?php endwhile; ?>
</tbody></table></div>
</div>
</main></body></html>
